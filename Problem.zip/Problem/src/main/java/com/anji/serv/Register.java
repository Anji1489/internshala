package com.anji.serv;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/RegisterServlet")
public class Register extends HttpServlet {
	 String url="jdbc:mysql://localhost:3306/database_name";
	 String un="root";
	 String pwd="password";
	 String sql="insert into register(name,uname,password) values(?,?,?)";
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn=DriverManager.getConnection(url, un, pwd);
			PreparedStatement ps=conn.prepareStatement(sql);
			resp.getWriter().println("Connection established");
			String name=req.getParameter("fullname");
			String uname=req.getParameter("email");
			String pass=req.getParameter("password");
			String cpwd=req.getParameter("confirmPassword");
			HttpSession sess=req.getSession();
			ps.setString(1, name);
			ps.setString(2, uname);
			ps.setString(3, pass);
			int n=ps.executeUpdate();
			sess.setAttribute("name", name);
			
			if(n!=0) {
				resp.sendRedirect("sucessreg.jsp");
			}
			else {
			resp.getWriter().println("Your details are:\n"+name+"\n"+uname+"\n"+pwd+"\n"+cpwd);
			}
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}
}
