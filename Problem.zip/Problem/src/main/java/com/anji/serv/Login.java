package com.anji.serv;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlet")
public class Login extends HttpServlet {
	String url="jdbc:mysql://localhost:3306/database";
	String un="root";
	String pass="password";
	String sql="select * from register where uname=? and password=?";
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn=DriverManager.getConnection(url,un,pass);
			PreparedStatement ps=conn.prepareStatement(sql);
			String name=req.getParameter("email");
			String pwd=req.getParameter("password");
			ps.setString(1, name);
			ps.setString(2, pwd);
			ResultSet rs=ps.executeQuery();
			
			if(rs.next()){
				resp.sendRedirect("agent.jsp");
			}
			
			resp.getWriter().println("Your details:"+name+"\n"+pwd);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
}
