package com.anji.serv;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/AddAgentServlet")
public class AddAgent extends HttpServlet{
	String url="jdbc:mysql://localhost:3306/database_name";
	String uname="root";
	String pwd="password";
	String sql="insert into agent(agent_name,email,mobile,password) values(?,?,?,?)";
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String name=req.getParameter("agentName");
		String email=req.getParameter("agentEmail");
		long mobile=Long.parseLong(req.getParameter("agentMobile"));
		String pass=req.getParameter("agentPassword");
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connn=DriverManager.getConnection(url,uname,pwd);
			PreparedStatement ps=connn.prepareStatement(sql);
			ps.setString(1, name);
			ps.setString(2, email);
			ps.setLong(3, mobile);
			ps.setString(4, pass);
			HttpSession sess=req.getSession();
			sess.setAttribute("name",name);
			
			int n=ps.executeUpdate();
			if(n!=0) {
				resp.sendRedirect("agentSuccess.jsp");
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}
}
